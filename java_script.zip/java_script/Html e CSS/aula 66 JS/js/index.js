
switch (key) {
    case value:
        
        break;

    default:
        break;
}

if(true){
    console.log("Olá mundo");
}